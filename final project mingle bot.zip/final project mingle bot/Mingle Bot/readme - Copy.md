# MINGLEBOT - AI-Powered Chatbot and Weather App

MINGLEBOT is an interactive AI chatbot integrated with various functionalities, including user authentication, real-time weather updates, multilingual conversation support, speech recognition, text-to-speech, and PDF chat history export.

## Features

- *User Authentication:*
  - User and Admin registration and login.
  - Securely stored credentials in an SQLite database.

- *Conversational AI Chatbot:*
  - Supports multilingual interactions.
  - Provides intelligent responses using Google Gemini Pro API.
  - Speech-to-text and text-to-speech capabilities.
  - Exports chat history to a PDF file.

- *Weather Forecast:*
  - Fetches real-time weather data using OpenWeather API.

- *Admin Dashboard:*
  - Displays user details in a structured format.

- *User-Friendly UI:*
  - Custom CSS styling for an enhanced experience.
  - Sidebar navigation for easy access.

## Installation & Setup

### Prerequisites
Ensure you have the following installed:
- Python 3.x
- Streamlit
- Required dependencies (listed below)

### Clone the Repository
sh
 git clone https://github.com/your-repo/minglebot.git
 cd minglebot


### Install Dependencies
sh
pip install -r requirements.txt


### Create .env File
Create a .env file in the root directory and add the following:

GOOGLE_API_KEY=your_google_api_key
OPENWEATHER_API_KEY=your_openweather_api_key


### Initialize Database
Run the following command to set up the SQLite database:
sh
python -c 'import sqlite3; conn = sqlite3.connect("users.db"); conn.cursor().execute("CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT NOT NULL, age INTEGER, profession TEXT, interests TEXT)"); conn.cursor().execute("CREATE TABLE IF NOT EXISTS admins (username TEXT PRIMARY KEY, password TEXT NOT NULL)"); conn.commit(); conn.close()'


### Run the Application
sh
streamlit run app.py


## Usage

1. *Login/Register*: Users and admins can register and log in.
2. *Chatbot*: Engage with the chatbot in multiple languages.
3. *Speech Recognition & Text-to-Speech*: Convert speech to text and listen to responses.
4. *Weather Forecast*: Enter a city name to get real-time weather updates.
5. *Admin Dashboard*: View all registered users.
6. *Export Chat History*: Download the conversation as a PDF.

## Technologies Used
- *Python*
- *Streamlit*
- *LangChain (Google Gemini Pro API)*
- *SpeechRecognition*
- *gTTS (Google Text-to-Speech)*
- *SQLite*
- *OpenWeather API*
- *FPDF (PDF generation)*

## Contributing
Feel free to fork the project and submit pull requests!

## License
This project is licensed under the MIT License.